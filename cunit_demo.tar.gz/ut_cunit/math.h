#ifndef __MY_MATH_H__
#define __MY_MATH_H__

#ifdef __cplusplus
extern "C" {
#endif

int sum(int num1, int num2);

#ifdef __cplusplus
}
#endif

#endif //__MY_MATH_H__
